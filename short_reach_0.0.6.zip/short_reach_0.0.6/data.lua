data.raw["character"]["character"].build_distance = 1
data.raw["character"]["character"].drop_item_distance = 1
data.raw["character"]["character"].item_pickup_distance = 1
data.raw["character"]["character"].loot_pickup_distance = 1
data.raw["character"]["character"].reach_distance = 1
data.raw["character"]["character"].reach_resource_distance = 1
